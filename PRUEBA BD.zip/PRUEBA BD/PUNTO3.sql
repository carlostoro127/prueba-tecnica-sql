/*CREAR SP*/
CREATE OR ALTER PROCEDURE sp_buscar_empleado
    @Nombre VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.IdEmpleado,
        e.Nombre,
        e.Apellido,
        e.Email,
        e.FechaIngreso,
        d.IdDepartamento,
        d.Nombre AS Departamento
    FROM Empleados e
    INNER JOIN Departamentos d
        ON e.IdDepartamento = d.IdDepartamento
    WHERE e.Nombre LIKE '%' + @Nombre + '%';
END;
GO

/*CREAR FUNCION*/
CREATE OR ALTER FUNCTION fn_total_proyectos
(
    @IdEmpleado INT
)
RETURNS INT
AS
BEGIN
    DECLARE @Total INT;

    SELECT @Total = COUNT(*)
    FROM EmpleadoProyecto
    WHERE IdEmpleado = @IdEmpleado;

    RETURN @Total;
END;
GO