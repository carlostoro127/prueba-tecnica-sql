/*Listar todos los empleados con el nombre de su departamento.*/

SELECT
    e.IdEmpleado,
    e.Nombre,
    e.Apellido,
    e.Email,
    d.Nombre AS Departamento
FROM Empleados e
INNER JOIN Departamentos d
    ON e.IdDepartamento = d.IdDepartamento;
/*Mostrar los proyectos con su presupuesto y la cantidad de empleados asignados. */
SELECT
    p.IdProyecto,
    p.Nombre,
    p.Presupuesto,
    COUNT(ep.IdEmpleado) AS CantidadEmpleados
FROM Proyectos p
LEFT JOIN EmpleadoProyecto ep
    ON p.IdProyecto = ep.IdProyecto
GROUP BY
    p.IdProyecto,
    p.Nombre,
    p.Presupuesto;
/*Obtener el top 3 de empleados con más proyectos asignados. */	
	SELECT TOP 3
    e.IdEmpleado,
    e.Nombre,
    e.Apellido,
    COUNT(ep.IdProyecto) AS CantidadProyectos
FROM Empleados e
INNER JOIN EmpleadoProyecto ep
    ON e.IdEmpleado = ep.IdEmpleado
GROUP BY
    e.IdEmpleado,
    e.Nombre,
    e.Apellido
ORDER BY
    CantidadProyectos DESC;
	
/*Listar los departamentos que no tienen empleados*/	
	SELECT
    d.IdDepartamento,
    d.Nombre
FROM Departamentos d
LEFT JOIN Empleados e
    ON d.IdDepartamento = e.IdDepartamento
WHERE e.IdEmpleado IS NULL;

/*Consultar todos los empleados que participan en más de un proyecto.*/
SELECT
    e.IdEmpleado,
    e.Nombre,
    e.Apellido,
    COUNT(ep.IdProyecto) AS CantidadProyectos
FROM Empleados e
INNER JOIN EmpleadoProyecto ep
    ON e.IdEmpleado = ep.IdEmpleado
GROUP BY
    e.IdEmpleado,
    e.Nombre,
    e.Apellido
HAVING COUNT(ep.IdProyecto) > 1;