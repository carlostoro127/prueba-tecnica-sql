/*CREACION DE INDICE*/
CREATE NONCLUSTERED INDEX IX_Empleados_Apellido
ON Empleados(Apellido);
GO

/*EXPLICACION BACKUP
Implementaría backups periódicos de la base de datos utilizando `BACKUP DATABASE`, almacenando los archivos `.bak` en una ubicación segura. 
Mantendría una política de backups completos y, según la criticidad, diferenciales y de log. Para recuperar la base utilizaría `RESTORE DATABASE` 
desde el archivo `.bak`. Validaría periódicamente los backups mediante restauraciones de prueba. También mantendría copias fuera del servidor principal.

*/
